<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function index()
	{

		$this->load->model(array('News_model','Tipster_model'));
		$data = array();
		$data['_widget_last_news'] = $this->News_model->_widget_last_news();
		$data['tipster_list'] = $this->Tipster_model->tipster_list();
		$array_match = json_decode(file_get_contents("http://bolaworld.com/ws/dokter_bola_fixtures/limit/20/10/format/json"));
		$data['matches'] = $array_match;
		$this->web_templater->main('page/home',$data);

	}

	public function logout() {
		$this->session->sess_destroy();
		redirect('http://dokterbola-fe.com/','refresh');
	}



}
