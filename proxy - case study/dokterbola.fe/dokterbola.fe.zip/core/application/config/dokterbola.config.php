<?php


$config['recaptcha_sitekey'] = '6LfiXgcUAAAAAOQFkPpQrYL5qVmZJTNHv592UwFR';
$config['recaptcha_secret'] = '6LfiXgcUAAAAAAHmjEnZCcKsK-j1qWQHDHDphurm';

$config['meta_title_suffix'] = ' - Dokter Bola - Informasi Agen Bola Terpercaya dan Agen Bola Penipu';
$config['meta_title_suffix_2'] = ' - Dokter Bola';
$config['meta_title_prefix'] = 'Agen Bola - ';
$config['success_vote_agent'] = '<strong>Berhasil!</strong>. <br/>Terimakasih, Anda telah berpartisipasi untuk mewujudkan Agen Bola Indonesia lebih baik.';
$config['duplicate_vote_found'] = '<strong>Gagal!</strong>. <br/>Maaf Anda Tidak Bisa Melakukan Rekomendasi Lagi Karena Terdapat Kesamaan IP Address dan atau Username';
$config['error_vote'] = '<strong>Terjadi Kesalahan.</strong><br/>Hubungi kami di halaman contact us atau langsung ke livechat kami. Terimakasih';


