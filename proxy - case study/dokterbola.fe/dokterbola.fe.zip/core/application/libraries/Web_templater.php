<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_templater {

	private $CI;
	

	public function __construct()
	{
		$this->CI =& get_instance();
		
	}


	public function main($view, $data = array())
	{

		$e_data = array();
		$e_data = $this->CI->web_global->default_data();

		$t_data = array();
		$t_data['_widget_top_agent'] = $this->CI->Agent_model->_widget_top_agent();
		$t_data['_widget_last_togel'] = $this->CI->Togel_model->_widget_last_togel();

		$t_data['_data_games'] = $this->CI->Agent_model->get_games();
		$t_data['_data_products'] = $this->CI->Agent_model->get_products();
		$t_data['_data_promotions'] = $this->CI->Agent_model->get_promotions();

		$t_data['_widget_random_gallery'] = $this->CI->Wag_model->_widget_random_gallery();
		$t_data['_widget_video_youtube'] = $this->CI->web_global->_widget_video_youtube();

		$t_data['_ads_left'] = $this->CI->Ads_model->_data_ads('L');
		$t_data['_ads_right'] = $this->CI->Ads_model->_data_ads('R');
		$t_data['_ads_top'] = $this->CI->Ads_model->_data_ads('T');
		$t_data['_ads_bottom'] = $this->CI->Ads_model->_data_ads('B');
		$t_data['_ads_bottom_float'] = $this->CI->Ads_model->_data_ads('BF');

		
		$m_data = array_merge($e_data, $t_data, $data);
		
		$this->CI->parser->parse('inc/header', $m_data);
		$this->CI->parser->parse($view, $m_data);
		$this->CI->parser->parse('inc/footer', $m_data);
	
	}


	




}