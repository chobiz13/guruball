/*=======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.2.3
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2016 vBulletin Solutions Inc. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
function vB_QuickEditor_VisitorMessage_Vars(A){this.init()}vB_QuickEditor_VisitorMessage_Vars.prototype.init=function(){this.target="visitormessage.php";this.postaction="message";this.objecttype="vmid";this.getaction="message";this.ajaxtarget="visitormessage.php";this.ajaxaction="quickedit";this.deleteaction="deletevm";this.messagetype="vmessage_message_";this.containertype="vmessage_";this.responsecontainer="commentbits"};