<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_Global {

	private $CI;
	private $type;



	public function __construct()
	{
		$this->CI =& get_instance();
	
	}

	public function check_login()
	{	
		$userdata = array();
		if(isset($_COOKIE['sessionhash'])){
			$sessionhash = $_COOKIE['sessionhash'];
			$userdata = $this->CI->Login_model->get_userdata($sessionhash);
			return $userdata;
		}else{
			$userdata = NULL;
			return $userdata;
		}

	}

    public function generateRandomString($length = 20) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

		
	public function default_data()
	{

		$data['base_url'] = base_url();
		$data['meta_title'] = 'Dokter Bola : Informasi Agen Bola Terpercaya dan Agen Bola Penipu';
		$data['meta_keywords'] = 'Informasi Agen Bola, Informasi Agen Casino, Agen Bola Terpercaya, Agen Bola Terbaik, Agen Bola Tidak Bayar, Agen Bola Penipu, Agen Bola, Agen Bola Pembayaran Terbaik, Berita Bola, Forum Bola';
		$data['meta_description'] = 'Sumber informasi agen bola online yang aman dan terpercaya';
		$data['user_data'] = $this->check_login();
		$data['login_check'] = ($data['user_data'] != NULL?  ($data['user_data'][0]->userid ? true : false) : false);
	
		return (array) $data;
	}

	public function _widget_video_youtube()
	{
		$url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&channelId=UCkUIebBd4wkEOmcC0PGAKUQ&key=AIzaSyDg_k2MFoOyHbSm0FGZ2j0r_mX5py8IhR4&order=date';
        $content = file_get_contents($url);
        $json = json_decode($content);
        $video_id = $json->items[0]->id->videoId;
        $title = $json->items[0]->snippet->title;
        $description = $json->items[0]->snippet->description;
        $image = $json->items[0]->snippet->thumbnails->high->url;
        $url_yourtube = 'https://www.youtube.com/watch?v=' . $video_id;
        return $video_id;
	}

	


	public function get_ipaddress() {
	   	$ip = file_get_contents('https://api.ipify.org');
		return $ip;	
	}

	
	
}