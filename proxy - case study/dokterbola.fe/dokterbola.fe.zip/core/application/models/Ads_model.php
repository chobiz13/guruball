<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ads_model extends CI_Model {

	const __TABLE_BANNER = 'adsbanner';

	public function __construct() 
	{
		parent::__construct();
	}

	public function _data_ads($pos)
	{
		$tbl_banner = self::__TABLE_BANNER;
		$data[] = $pos;
		$sql = "SELECT  id_adsbanner as id,
						nama as name, 
						url as target_link,
						gambar as image,
						position,`order`,
						status,tanggal as date
				FROM `$tbl_banner` ads 
				WHERE position = ? AND ads.status=1
				ORDER BY `order`";
		$query = $this->db->query($sql,$data);	
		$result = $query->result();
		
		return $result;
		
	}



}